<?php
require_once "koneksi.php";
class Manggota 
{
	public  function get_data()
	{
		global $mysqli;
		$query="SELECT * FROM anggota";
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
							'status' 	=> 200,
							'message' 	=> 'Get List anggota Successfully.',
							'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
	}

	public function get_data_by_id($id=0)
	{
		global $mysqli;
		$query="SELECT * FROM anggota";
		if($id != 0)
		{
			$query.=" WHERE id_anggota =".$id." LIMIT 1";
		}
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
						'status' 	=> 200,
						'message' 	=> 'Get Data anggota Successfully.',
						'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
		 
	}

	public function insert_data()
		{
			global $mysqli;
						
					$result = mysqli_query($mysqli, "INSERT INTO anggota SET
								id_anggota 	= '$_POST[id_anggota]',
								kode_anggota 	= '$_POST[kode_anggota]',
								nama_anggota 	= '$_POST[nama_anggota]',
								email_anggota = '$_POST[email_anggota]'	");
								
					if($result)
					{
						$response=array(
							'status' => 1,
							'message' =>'Mahasiswa Added Successfully.'
						);
					}
					else
					{
						$response=array(
							'status' => 0,
							'message' =>'Mahasiswa Addition Failed.'
						);
					}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function update_data($id)
		{
			global $mysqli;
		
			
		        $result = mysqli_query($mysqli, "UPDATE anggota SET
										kode_anggota 	= '$_POST[kode_anggota]',
										nama_anggota 	= '$_POST[nama_anggota]',
										email_anggota = '$_POST[email_anggota]'
										WHERE id_anggota ='$id'");		   
				if($result)
				{
					$response=array(
						'status' => 1,
						'message' =>'Mahasiswa Updated Successfully.'
					);
				}
				else
				{
					$response=array(
						'status' => 0,
						'message' =>'Mahasiswa Updation Failed.'
					);
				}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function delete_data($id)
	{
		global $mysqli;
		$query="DELETE FROM anggota WHERE id_anggota=".$id;
		if(mysqli_query($mysqli, $query))
		{
			$response=array(
				'status' => 1,
				'message' =>'Mahasiswa Deleted Successfully.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'message' =>'Mahasiswa Deletion Failed.'
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
}

 ?>