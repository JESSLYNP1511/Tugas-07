<?php
$host	= "localhost";
$user	= "root";
$pass	= "";
$db		= "library";
	
$mysqli = new mysqli($host, $user, $pass, $db);
?>
