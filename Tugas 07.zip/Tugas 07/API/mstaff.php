<?php
require_once "koneksi.php";
class Mstaff 
{
	public  function get_data()
	{
		global $mysqli;
		$query="SELECT * FROM staff";
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
							'status' 	=> 200,
							'message' 	=> 'Get List Staff Successfully.',
							'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
	}

	public function get_data_by_id($id=0)
	{
		global $mysqli;
		$query="SELECT * FROM staff";
		if($id != 0)
		{
			$query.=" WHERE id_staff =".$id." LIMIT 1";
		}
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
						'status' 	=> 200,
						'message' 	=> 'Get Data Staff Successfully.',
						'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
		 
	}

	public function insert_data()
		{
			global $mysqli;
						
					$result = mysqli_query($mysqli, "INSERT INTO staff SET
								id_staff 	= '$_POST[id_staff]',
								kode_staff 	= '$_POST[kode_staff]',
								username 	= '$_POST[username]',
								nama_staff 	= '$_POST[nama_staff]',
								password 	= '$_POST[password]',
								email_staff = '$_POST[email_staff]'	");
								
					if($result)
					{
						$response=array(
							'status' => 1,
							'message' =>'Mahasiswa Added Successfully.'
						);
					}
					else
					{
						$response=array(
							'status' => 0,
							'message' =>'Mahasiswa Addition Failed.'
						);
					}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function update_data($id)
		{
			global $mysqli;
		
			
		        $result = mysqli_query($mysqli, "UPDATE staff SET
										kode_staff 	= '$_POST[kode_staff]',
										username 	= '$_POST[username]',
										nama_staff 	= '$_POST[nama_staff]',
										password 	= '$_POST[password]',
										email_staff = '$_POST[email_staff]'	
										WHERE id_staff ='$id'");		   
				if($result)
				{
					$response=array(
						'status' => 1,
						'message' =>'Mahasiswa Updated Successfully.'
					);
				}
				else
				{
					$response=array(
						'status' => 0,
						'message' =>'Mahasiswa Updation Failed.'
					);
				}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function delete_data($id)
	{
		global $mysqli;
		$query="DELETE FROM staff WHERE id_staff=".$id;
		if(mysqli_query($mysqli, $query))
		{
			$response=array(
				'status' => 1,
				'message' =>'Mahasiswa Deleted Successfully.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'message' =>'Mahasiswa Deletion Failed.'
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
}

 ?>