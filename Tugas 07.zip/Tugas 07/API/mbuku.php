<?php
require_once "koneksi.php";
class Mbuku 
{
	public  function get_data()
	{
		global $mysqli;
		$query="SELECT * FROM buku";
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
							'status' 	=> 200,
							'message' 	=> 'Get List buku Successfully.',
							'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
	}

	public function get_data_by_id($id=0)
	{
		global $mysqli;
		$query="SELECT * FROM buku";
		if($id != 0)
		{
			$query.=" WHERE id_buku =".$id." LIMIT 1";
		}
		$data=array();
		$result=$mysqli->query($query);
		while($row=mysqli_fetch_object($result))
		{
			$data[]=$row;
		}
		$response=array(
						'status' 	=> 200,
						'message' 	=> 'Get Data buku Successfully.',
						'data' 		=> $data
						);
		header('Content-Type: application/json');
		echo json_encode($response);
		 
	}

	public function insert_data()
		{
			global $mysqli;
						
					$result = mysqli_query($mysqli, "INSERT INTO buku SET
								id_buku 	= '$_POST[id_buku]',
								kode_buku 	= '$_POST[kode_buku]',
								judul_buku 	= '$_POST[judul_buku]',
								pengarang_buku 	= '$_POST[pengarang_buku]',
								status_buku 	= '$_POST[status_buku]' ");
								
					if($result)
					{
						$response=array(
							'status' => 1,
							'message' =>'Mahasiswa Added Successfully.'
						);
					}
					else
					{
						$response=array(
							'status' => 0,
							'message' =>'Mahasiswa Addition Failed.'
						);
					}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function update_data($id)
		{
			global $mysqli;
		
			
		        $result = mysqli_query($mysqli, "UPDATE buku SET
										kode_buku 	= '$_POST[kode_buku]',
								judul_buku 	= '$_POST[judul_buku]',
								pengarang_buku 	= '$_POST[pengarang_buku]',
								status_buku 	= '$_POST[status_buku]'	
										WHERE id_buku ='$id'");		   
				if($result)
				{
					$response=array(
						'status' => 1,
						'message' =>'Mahasiswa Updated Successfully.'
					);
				}
				else
				{
					$response=array(
						'status' => 0,
						'message' =>'Mahasiswa Updation Failed.'
					);
				}
			
			header('Content-Type: application/json');
			echo json_encode($response);
		}

	function delete_data($id)
	{
		global $mysqli;
		$query="DELETE FROM buku WHERE id_buku=".$id;
		if(mysqli_query($mysqli, $query))
		{
			$response=array(
				'status' => 1,
				'message' =>'Mahasiswa Deleted Successfully.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'message' =>'Mahasiswa Deletion Failed.'
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
}

 ?>